/*
Los papois
18/09/2024
codigos fork (proceso padre e hijo)
*/


#include <unistd.h> // nos proporciona acceso a funciones del sistema Unix, como el fork() y sleep()
#include <stdlib.h> // funciones estardar como exit()
#include <stdio.h>  // impresiones de pantalla printf()
int main() {
    pid_t rf; // nos funciona para almacenar los ID de los procesos, numeros unicos 
    rf = fork(); // Se llama a la función fork(), que crea un nuevo proceso. Esta función retorna dos valores diferentes:
                 //  - En el proceso padre, retorna el PID (Process ID) del hijo.
                 //  - En el proceso hijo, retorna 0.
                 //  - Si ocurre un error, retorna -1.
    switch (rf) {
        case -1: // En caso de que fork() retorne -1, significa que no se pudo crear el proceso hijo.
            printf("\nNo he podido crear el proceso hijo");
            break;
        case 0: // En el proceso hijo, fork() retorna 0
            printf("\nSoy el hijo, mi PID es %d y mi PPID es %d", getpid(), getppid());
            sleep(10);
            break;
        default: // En el proceso padre, fork() retorna el PID del hijo.
            printf("\nSoy el padre, mi PID es %d y el PID de mi hijo es %d", getpid(), rf);
    }

    // Este printf() se ejecutará por el proceso padre y no pasara por el hijo por no tener un sleep()
    printf("\nFinal de ejecucion de %d \n", getpid());
    exit(0);
}

/* al momento de ejecutar el programa se realiza el inicio de el procesos original el proceso padre y consecutivamente se inicia un nuevo proceso el hijo
ambos procesos conservan sus PID, al momento de que el proceso se inicia el procesos padre copia el PID del hijo con lo cual el rf el mayor a 0 y entra al proceso padre imprimiendo 
el caso en el que rf es mayor a 0 y en este paso como no hay un sleep no permite que el proceso hijo entre ya que regresa el PID del padre de inmediato, por no tener un tiempo de espera
y solo imprime el proceso padre y no el del hijo por ser dos procesos diferentes y no tener tiempo de reaccionar.
*/