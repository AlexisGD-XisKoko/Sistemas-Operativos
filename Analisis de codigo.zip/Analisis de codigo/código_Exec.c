/*
Los papois
18/10/2024
Codido de Exec
*/


#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h> // Necesario para manejar errores de sistema

int main(int argc, char *argv[]) {
    int i;

    // Mostrar los argumentos recibidos por el programa
    printf("Ejecutando el programa invocador (execprog1). Sus argumentos son:\n");
    
    // Recorremos todos los argumentos y los imprimimos
    for (i = 0; i < argc; i++) {
        printf("argv[%d]: %s\n", i, argv[i]);
    }
    
    // Esperamos 10 segundos antes de continuar, por ejemplo, para observar el estado del proceso
    sleep(10);
    
    // Cambiamos el primer argumento (argv[0]) para que sea "execprog2"
    // Esto no afecta la ejecución, pero cambia cómo se verá el programa cuando se ejecute.
    argv[0] = "execprog2";
    
    // Usamos execv para reemplazar este proceso por el programa execprog2
    // Le pasamos los mismos argumentos que recibió originalmente este programa
    if (execv("./execprog2", argv) < 0) {
        // Si execv falla, mostramos el error correspondiente usando perror para obtener más detalles
        perror("Error en la invocación a execprog2");
        exit(1); // Salimos con código de error
    }

    // Si execv tiene éxito, este código nunca se ejecutará, porque el proceso actual es reemplazado
    exit(0);
}