/*
Los papois 
18/10/24
*/


#include<stdio.h>
#include<errno.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<sys/wait.h>

// Funci�n que el proceso hijo usar� para leer del pipe
void imprimeDePipe(int leePipe);

// Funci�n que el proceso padre usar� para escribir en el pipe
void enviaAPipe(int escribePipe);

int main(){
    pid_t procHijo;  // Variable para almacenar el ID del proceso hijo
    int pipeFileDescriptors[2];  // Array para los descriptores de archivo del pipe (lectura y escritura)
    
    // Crear el pipe (un canal de comunicaci�n entre procesos)
    if(pipe(pipeFileDescriptors) == -1){  // Si hay un error al crear el pipe
        printf("Error al crear pipe\n");
        return 1;
    }

    // Crear el proceso hijo usando fork()
    procHijo = fork();
    if(procHijo < 0){  // Si fork() devuelve un valor negativo, hubo un error
        int errnum = errno; //ligera modificacion en la variable
        printf("Error %d al generar proceso hijo con fork\n", errnum);
        exit(1);
    }

    // Este bloque lo ejecuta el proceso hijo
    if(procHijo == 0){
        // El proceso hijo no necesita escribir en el pipe, as� que cerramos el extremo de escritura
        close(pipeFileDescriptors[1]);
        // Llamamos a la funci�n que leer� datos del pipe
        imprimeDePipe(pipeFileDescriptors[0]);  // Lee del pipe y muestra en pantalla
    }

    // Este bloque lo ejecuta el proceso padre
    if(procHijo > 0){
        // El proceso padre no necesita leer del pipe, as� que cerramos el extremo de lectura
        close(pipeFileDescriptors[0]);
        // Llamamos a la funci�n que solicitar� entrada del usuario y la enviar� al pipe
        enviaAPipe(pipeFileDescriptors[1]);  // Env�a los datos al pipe
        // Esperamos a que el proceso hijo termine 
        wait(NULL);
    }

    return 0;
}

// Funci�n que lee datos del pipe (la usa el proceso hijo) 
void imprimeDePipe(int leePipe){
    char buf;  // Buffer para almacenar el car�cter le�do
    printf("Proceso hijo, esperando cadena...\n");
    // Bucle que lee car�cter por car�cter del pipe hasta que no haya m�s datos
    while(read(leePipe, &buf, 1) > 0)
        write(STDOUT_FILENO, &buf, 1);  // Escribe el car�cter en la salida est�ndar 
    write(STDOUT_FILENO, "\n", 1);  // A�ade un salto de l�nea al final
    close(leePipe);  // Cerramos el descriptor de lectura del pipe
    printf("Proceso hijo, finalizado\n");
    exit(0);  // Terminamos el proceso hijo
}

// Funci�n que escribe datos en el pipe (la usa el proceso padre)
void enviaAPipe(int escribePipe){
    char buf[10];  // Buffer para almacenar la cadena ingresada por el usuario
    printf("Proceso padre, ingresa una cadena de 10 caracteres y enter:\n");
    // Leer una cadena de 10 caracteres del usuario
    scanf("%10s", buf);  // Usamos %10s para limitar la entrada a 10 caracteres. Se cambi� el %10c para asegurar que solo se lean hasta 10 caracteres.
    write(escribePipe, buf, strlen(buf));  // Escribimos los caracteres en el pipe
    close(escribePipe);  // Cerramos el descriptor de escritura del pipe
    printf("Datos enviados al pipe. Terminando proceso padre.\n");
}
