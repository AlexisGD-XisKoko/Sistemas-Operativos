/*
Los papois
18/10/24
codigos fork (proceso padre e hijo)
*/


#include <unistd.h> // Librería necesaria para usar funciones como fork(), getpid(), getppid() y sleep().
#include <stdio.h>  // Librería estándar para entrada y salida, como printf().
#include <stdlib.h> // Librería estándar de C para funciones como exit().

int main() {
    pid_t rf; // Se declara una variable de tipo pid_t que almacenará el valor devuelto por fork().

    rf = fork(); // Se llama a la función fork(), que crea un nuevo proceso. Esta función retorna dos valores diferentes:
                 //  - En el proceso padre, retorna el PID (Process ID) del hijo.
                 //  - En el proceso hijo, retorna 0.
                 //  - Si ocurre un error, retorna -1.

    // Se utiliza un switch para manejar los tres posibles resultados de fork().
    switch (rf) {
       case -1: // En caso de que fork() retorne -1, significa que no se pudo crear el proceso hijo.
             printf("No he podido crear el proceso hijo \n");
             break;

       case 0: // En el proceso hijo, fork() retorna 0.
            printf("Soy el hijo, mi PID es %d y mi PPID es %d \n", getpid(), getppid());
            // getpid() retorna el PID del proceso actual (el hijo).
            // getppid() retorna el PID del proceso padre.
            
            sleep(20); // Suspende la ejecución del proceso hijo por 20 segundos.
            break;

      default: // En el proceso padre, fork() retorna el PID del hijo.
            printf("Soy el padre, mi PID es %d y el PID de mi hijo es %d \n", getpid(), rf);
            // getpid() retorna el PID del proceso actual (el padre).
            // rf contiene el PID del proceso hijo, retornado por fork().

            sleep(30); // Suspende la ejecución del proceso padre por 30 segundos.
                      // El proceso padre se suspenderá por más tiempo que el hijo (30 segundos vs. 20 segundos),
                      // lo que implica que el hijo terminará antes que el padre.
    }

    // Este printf() se ejecutará tanto en el proceso padre como en el hijo, después de que ambos terminen su sleep().
    printf("Final de ejecución de %d \n", getpid());
    
    exit(0); // Finaliza el proceso actual (padre o hijo) con un código de salida 0, indicando que terminó correctamente.
}
